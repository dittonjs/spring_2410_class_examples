package com.usu.minesweeperstarter;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // TODO: create the views for the main page and transition
        //  to the main page once the difficulty is selected
    }
}